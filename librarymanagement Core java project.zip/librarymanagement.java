
import java.util.*;
public class librarymanagement {
	public static void main(String args[])
	{
		
		
		Scanner sc=new Scanner(System.in);
		String name = null,mail = null,address=null,contact=null;
		login ac=new login();
		while(true)
		{
			System.out.println("Welcome!!");
			System.out.println("Please Press 1 Register or already   press 2 for further");
			int l=sc.nextInt();
			if(l==1)
		    {
				ac.get(name,mail,address,contact);
			  System.out.println("Enter your name please");
			  name=sc.next();
			  System.out.println("Enter mailid");
			  mail=sc.next();
			  System.out.println("Enter your address");
			  address=sc.next();
			  System.out.println("Enter contact number");
			  contact=sc.next();
			  System.out.println("Thank You for registration");
			 ac. pass();
			}
			else
			{
				System.out.println("Enter your Id Please");
				int iiid;
				iiid=sc.nextInt();
				if(ac.id==iiid)
				{
					System.out.println("which book You want");
					String book;
					book=sc.next();
					System.out.println("which auther");
					String auther;
					auther=sc.next();
					System.out.println("Thank You !!!!!");
				}
					else
					{
						System.out.println("Wrong Id");
					}
					
					
				}
			}
		}
		
	}


class login
{
	static int custid=0;
	int id;
	String name,mail,address,contact;
	public  void get(String name,String mail,String address,String contact)
	{
		this.name=name;
		this.mail=mail;
		this.address=address;
		this.contact=contact;
		this.id=++login.custid;
		
		
	}
	void pass() 
	{
		System.out.println("yr id is"+" "+id);
	}
	
}

	